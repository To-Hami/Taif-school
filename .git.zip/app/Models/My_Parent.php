<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class My_Parent extends Model
{


    protected $table = 'my__parents';
    protected $guarded=[];
    public $timestamps;
}
