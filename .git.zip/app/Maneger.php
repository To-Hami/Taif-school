<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Maneger extends Model
{
    protected $guarded = [];

}
