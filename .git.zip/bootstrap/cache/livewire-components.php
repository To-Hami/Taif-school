<?php return array (
  'add-parent' => 'App\\Http\\Livewire\\AddParent',
);